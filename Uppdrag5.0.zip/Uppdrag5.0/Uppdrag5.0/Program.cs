﻿using System;

namespace Uppdrag5._0
{
    class Program
    {
        static void Main(string[] args)
        {
            // print-out
            Circle demo = new Circle(5);
            Console.WriteLine(demo.getArea());


            Circle demo1 = new Circle(6);
            Console.WriteLine(demo1.getArea());

        }
    }

    public class Circle
    {
        int radius;
        float pi = 3.141f;

        // Constructor
        public Circle(int radius)
        {
            this.radius = radius;
            
        }
        //Metod
        public float getArea()
        {
            float aria = radius * radius * pi;
            return aria;
        }
    }
}
